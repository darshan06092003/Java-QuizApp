package com.formdev.flatlaf;

import javax.swing.LookAndFeel;

public class FlatLightLaf extends LookAndFeel {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isNativeLookAndFeel() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSupportedLookAndFeel() {
		// TODO Auto-generated method stub
		return false;
	}

}
