package org.projectgurukul;

import java.sql.Connection;

public class SQLiteDataSource {

	public void setUrl(String string) {
		// TODO Auto-generated method stub
		
	}

	public Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}

}
